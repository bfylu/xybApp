(function ($) {
    $.mobiscroll.i18n.zh = $.extend($.mobiscroll.i18n.zh, {
        setText: '确认',
        cancelText: '取消'
    });
})(jQuery);
