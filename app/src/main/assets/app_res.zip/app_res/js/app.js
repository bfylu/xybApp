var AppData = {};
var opSys = typeof(App) == "undefined" ? "ios" : "android";
var AppInterface = {
	getUserInfo: function() {
		if (opSys == "ios") {
			setupWebViewJavascriptBridge(function(bridge) {
				bridge.registerHandler("App_getUserInfo", function(data, responseCallback) {
//					showToast(data);
					AppData.userInfo = JSON.stringify(data);
					if(null != BridgeCallback) {
						var data = JSON.stringify(data);
						BridgeCallback(data);
					}
				});
			});
		} else {
			AppData.userInfo = App.getUserInfo();
			if (null != BridgeCallback) {
				BridgeCallback(App.getUserInfo());
			}
		}
		return AppData.userInfo;
	},
	installmentPay: function(installmentType, orderAmount, goodsList) {
		if (opSys == "ios") {
			setupWebViewJavascriptBridge(function(bridge) {
				bridge.callHandler('App_installmentPay',
					{"installmentType": installmentType, "orderAmount": orderAmount, "goodsList": goodsList},
					function responseCallback(responseData) {
						
					}
				);
			});
			
		} else {
			App.installmentPay(installmentType, orderAmount, goodsList);
		}
	},
	pay: function(orderAmount, goodsList) {
		
		if (opSys == "ios") {
//			App_pay(orderAmount, goodsList);
			setupWebViewJavascriptBridge(function(bridge) {
				bridge.callHandler('App_pay',{"orderAmount": orderAmount, "goodsList": goodsList},
					function responseCallback(responseData) {
						
					}
				);
		});
		
		} else {
			App.pay(orderAmount, goodsList);
		}
	},
	openGoodsManager: function() {
		if (opSys == "ios") {
			setupWebViewJavascriptBridge(function(bridge) {
				bridge.callHandler('App_openGoodsManager', {}, function(data, responseData) {
					
				});
			});
			
		} else{
//			showToast("android");
			App.openGoodsManager();
		}
	},
	scanBarCode : function(){
		if (opSys == "ios") {
			setupWebViewJavascriptBridge(function(bridge) {
				bridge.registerHandler("setBarCode", function(data, responseCallback) {
					AppCallback.setBarCode(data);
				});
				bridge.callHandler('App_scanBarCode', {}, function(responseData) {
					
				});
			});
		} else {
			App.scanBarCode();
		}
	},
	goBack : function(){
		
		if (opSys == "ios") {
			
			setupWebViewJavascriptBridge(function(bridge) {
				bridge.callHandler('App_goBack', {}, function(data, responseData) {});
			});
			
		} else{
			App.goBack();
		}
	},
	backToHome : function(){
		
		if (opSys == "ios") {
			
			setupWebViewJavascriptBridge(function(bridge) {
				bridge.callHandler('App_backToHome', {}, function(data, responseData) {});
			});
			
		} else{
			App.backToHome();
		}
	},
}

var AppCallback = {
	setOperatorType: function(opType) {
		AppCallback.opType = opType;
	},
	getOperatorType: function() {
		return AppCallback.opType;
	},
	setBarCode : function(barCode) {
		
		if (AppCallback.opType == 1) {
			
			$("#barCode").parent().children(".errorInfo").remove();
			$("#barCode").show();
			$("#barCode").val(barCode);
			
		} else if (AppCallback.opType == 2) {
			
			getBarCode(barCode);
		}
	}
}

function setupWebViewJavascriptBridge(callback) {
	if (window.WebViewJavascriptBridge) {
		return callback(WebViewJavascriptBridge);
	} else if (window.WVJBCallbacks) {
		return window.WVJBCallbacks.push(callback);
	}
	window.WVJBCallbacks = [callback];
	var WVJBIframe = document.createElement('iframe');
	WVJBIframe.style.display = 'none';
	WVJBIframe.src = 'https://__bridge_loaded__';
	document.documentElement.appendChild(WVJBIframe);
	setTimeout(function() { document.documentElement.removeChild(WVJBIframe) }, 0);
	
}

//if (opSys == "ios") {
//	AppInterface.getUserInfo();
//}