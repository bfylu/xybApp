
function goBack(){
//	self.location=document.referrer;
	window.history.go(-1);
//	self.location = document.referrer;
}

function closePop(){
	
}


/*声明全局变量放置进件资料*/
var incomingData = {};

var optCookie = {
	getCookie:function(c_name){
		if (document.cookie.length>0) {
		  	c_start=document.cookie.indexOf(c_name + "=")
		  	if (c_start!=-1){ 
		    	c_start=c_start + c_name.length+1 
		    	c_end=document.cookie.indexOf(";",c_start)
		    if (c_end==-1) c_end=document.cookie.length
		    	return unescape(document.cookie.substring(c_start,c_end))
		    } 
		}
		return ""
	},
	setCookie:function(c_name,value,expiredays){
		var exdate=new Date()
		exdate.setDate(exdate.getDate()+expiredays)
		document.cookie = c_name+ "=" +escape(value)+
		((expiredays==null) ? "" : ";expires="+exdate.toGMTString())+";path=/";
	},
	
	delCookie:function(name){
		optCookie.setCookie(name,"",-1);
	}
}
var isAndroid = window.navigator.appVersion.match(/android/gi);
var isIPhone = window.navigator.appVersion.match(/iphone/gi);

/**
 * js工具类
 */
var JsUtil = {
	
	getUrlParams: function() {
		var data = {};
		var currentUrl = location.href;
		var index = currentUrl.indexOf("?");
		if(index == -1) {
			return data;
		}

		var params = currentUrl.substring(index + 1);
		var paramsSeq = params.split("&");

		for(var i = 0, j = paramsSeq.length; i < j; i++) {
			var split = paramsSeq[i].split("=");
			var k = split[0];
			var v = decodeURI(split[1]);
			data[k] = v;
		}

		return data;
	},
	
	formatDate: function(now) {
		var newDate = new Date(now);
		var year = newDate.getFullYear();
		var month = newDate.getMonth() + 1;
		var date = newDate.getDate();
		var hour = newDate.getHours();
		var minute = newDate.getMinutes();
		var second = newDate.getSeconds();
		return year + "-" + JsUtil.timeAdd(month) + "-" + JsUtil.timeAdd(date) + "   " + JsUtil.timeAdd(hour) + ":" + JsUtil.timeAdd(minute) + ":" + JsUtil.timeAdd(second);
	},
	
	formatDateNoHour: function (nowD) {
		var newDate = new Date(nowD);
		var year = newDate.getFullYear();
		var month = newDate.getMonth() + 1;
		var date = newDate.getDate();
		return year + "-" + JsUtil.timeAdd(month) + "-" + JsUtil.timeAdd(date) ;
	},
	/**
	 * 截取日期格式不带时分秒
	 * */
	cutDateNoHour : function(data){
		var data = data.substring(0, data.indexOf(' '));
		return data;
	},
	timeAdd: function (m) {
		return m < 10 ? '0' + m : m
	},
	
	/**
	 * 是否在微信中打开
	 */
	isWeixinBrowser: function() {
		var ua = navigator.userAgent.toLowerCase();
		if(ua.match(/MicroMessenger/i) == "micromessenger") {
			return true;
		} else {
			return false;
		}
	},
	
	/**
	 * 是否在支付宝中打开
	 */
	isAlipayBrowser: function() {
		var ua = navigator.userAgent.toLowerCase();
		if(ua.match(/Alipay/i) == "Alipay" || ua.match(/alipay/i) == "alipay") {
			return true;
		} else {
			return false;
		}
	}

}

/**
 * 动态加载
 */
var DynamicLoading = {

	css: function(path) {
		if(!path || path.length === 0) {
			throw new Error('argument "path" is required !');
		}
		var head = document.getElementsByTagName('head')[0];
		var link = document.createElement('link');
		link.href = path;
		link.rel = 'stylesheet';
		link.type = 'text/css';
		head.appendChild(link);
	},

	js: function(path) {
		if(!path || path.length === 0) {
			throw new Error('argument "path" is required !');
		}
		var head = document.getElementsByTagName('head')[0];
		var script = document.createElement('script');
		script.src = path;
		script.type = 'text/javascript';
		head.appendChild(script);
	},

	/**
	 * 依赖jquery
	 * @param {Object} jNode
	 * @param {Object} pageUrl
	 * @param {Object} pageNodeId
	 * @param {Object} data
	 * @param {Object} callback
	 */
	page: function(jNode, pageUrl, callback) {
		
//		if(null == pageNodeId || undefined == pageNodeId) {
//			jNode.load(pageUrl + " #panel", data, callback);
//		} else {
			$("#"+jNode).load(pageUrl,callback);
//		}
	}
}

var CommonDialog = {
	show : function(params) {
		CommonDialogCallback = params.closePageCallback;
//		var width = params.width;
//		var height = params.height;
		var dialogId = params.dialogId;
		var pageUrl = params.pageUrl;
//		var pagePanelName = "panel";
		var loadPageCallback = params.loadPageCallback;
//		var offsetTop = ($(window).height() - height) / 2;
//		var offsetLeft = ($(window).width() - width) / 2;
		
		var commonDialog = $("#loadDiv");
//		var dialogPanel = $("#dialogPanel");
//		dialogPanel.width(width);
//		dialogPanel.height(height);
//		dialogPanel.css("top", offsetTop + "px");
//		dialogPanel.css("left", offsetLeft + "px");
//		var dialogTitle = $("#dialogTitle");
//		var dialogClose = $("#dialogClose");
//		dialogTitle.text(title);
//		dialogClose.click(function() {
//			CommonDialog.close();
//		});
//		var dialogContent = $("#dialogContent");
//		dialogContent.height(height - 40);
		DynamicLoading.page(dialogId, pageUrl,loadPageCallback);
		
		commonDialog.show();
	},
	close : function(data) {
		
		if (null != CommonDialogCallback) {
			CommonDialogCallback(data);
			CommonDialogCallback = null;
		}
		
//		var commonDialog = $("#commonDialog");
//		var dialogPanel = $("#dialogPanel");
//		var dialogTitle = $("#dialogTitle");
		var dialogContent = $("#loadDiv");
//		dialogTitle.text("");
		dialogContent.children().remove();
		dialogContent.hide();
	}
}

var isAndroid = window.navigator.appVersion.match(/android/gi);
var isIPhone = window.navigator.appVersion.match(/iphone/gi);
/**
 * 截取地址栏的参数
 */
function getUrlParam() {
	var currentUrl = location.href;
	var index = currentUrl.indexOf("?");
	if (index == -1) {
		return {};
	}
	
	var params = currentUrl.substring(index + 1);
	var paramsSeq = params.split("&");
	var data = {};
	for (var i = 0, j = paramsSeq.length; i < j; i++) {
		var split = paramsSeq[i].split("=");
		var k = split[0];
		var v = unescape(split[1]);
		console.log(k + "=" + v);
		data[k] = v;
	}
	
	return data;
}

function sendToServer(data) {
	var url = data.url;
	var success = data.success;
	var failure = data.failure;
	var sendData = data.data;
	var callback = data.callback;
	
	$.ajax({
		type:"post",
		url:url,
		data: sendData,
		dataType: "json",
		async:true,
		success: function(data) {
//			console.log(data);
			if (null == data || undefined == data) {
				console.log("没有返回数据");
				return;
			}
			if (data.respCode == "0000") {
				if (null != success) {
					success(data);
				} else {
					console.log("没有找到成功回调的处理方法");
				}
			} else {
				if (null != failure) {
					failure(data);
				} else {
					showToast(data.respDesc);
				}
			}
			if (null != callback) {
				callback();
			}
		},
		error: function() {
			showToast("网络错误");
			if (null != callback) {
				callback();
			}
		}
	});
}

function submitToServer (formId, params) {
		
	var sendData = params.data;
	var callback = params.callback;
	var autoHandlerFail = params.autoHandlerFail;
	var autoHandlerError = params.autoHandlerError;
	
	if (null != GlobalData.sessionToken && undefined != GlobalData.sessionToken) {
		sendData.sessionToken = GlobalData.sessionToken;
	}
	
//		console.log(sendData);
	
	$("#" + formId).ajaxSubmit({
		type:"post",
		data: sendData,
		dataType: "json",
		async: false,
		success: function(data) {
			
//				console.log(data);
			
			if (null == data || undefined == data) {
				return;
			}
			
			if (data.respCode == "0000") {
				callback(CallbackStatus.success, data);
			} else {
				if (autoHandlerFail) {
					callback(CallbackStatus.failure, data);
				} else {
					alert(data.respDesc);
				}
			}
		},
		error: function() {
			if (autoHandlerError) {
				callback(CallbackStatus.error, data);
			} else {
				alert("网络错误");
			}
		}
	});
}



/*上传图片显示缩略图*/
$(".uploadPhoto").on('change',".fileInput",function(){
	var _this = $(this);
	var fr = new FileReader();
	fr.readAsDataURL(this.files[0]);
//	console.log(this.files[0].type);
	if(this.files[0].type == "image/png" || this.files[0].type == "image/jpeg" || this.files[0].type == "image/jpg"){
//		if(this.files[0].size >= 50 * 1024 && this.files[0].size <= 1024 * 1024 * 10){
		if(this.files[0].size <= 1024 * 1024 * 10){
//			console.log(_this[0].id);
			$("#"+_this[0].id).attr("suppName",_this[0].id);
			console.log(_this[0].id+"-----"+$("#"+_this[0].id).attr("suppName"));
			var img = new Image();
			fr.onload = function() {
				img.src = this.result;
				var imgId = _this.parent().siblings().find(".j-img");
				imgId.html(img);
				imgId.css({"width":"10.15rem","height":"6.4rem","overflow":"hidden","display":"block","margin":"0.75rem auto"});
				imgId.find("img").css("height","100%");
				imgId.next("p").css("display","none");
				_this.next().removeClass("regetIos");
				_this.next().removeClass("regetAndroid");
			}
		}else{
			if (_this[0].id != $("#"+_this[0].id).attr("suppName")) {
				$('.applyBtn').prop('disabled',true);
				$('.applyBtn').css({backgroundColor: '#aaaaaa'});
			}
			showToast('上传的文件超过了大小限制，请重新上传');
		}
	}else{
		if (_this[0].id != $("#"+_this[0].id).attr("suppName")) {
			$('.applyBtn').prop('disabled',true);
			$('.applyBtn').css({backgroundColor: '#aaaaaa'});
		}
		showToast('上传的格式有误，请重新上传');
	}
});