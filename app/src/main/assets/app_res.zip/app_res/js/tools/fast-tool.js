/**
 * 
 */
var FastJs = {
	/**
	 * 格式化字符串
	 */
	messageFormat: function(msg, array) {

		var len = array.length;
		for(var i = 0, j = len; i < j; i++) {
			msg = msg.replace("{" + i + "}", array[i]);
		}

		return msg;
	},

	//判断是否在微信浏览器中打开
	isWeixinBrowser: function() {

		var ua = navigator.userAgent.toLowerCase();
		if(ua.match(/MicroMessenger/i) == "micromessenger") {
			return true;
		} else {
			return false;
		}
	},

	// 判断是否在支付宝浏览器中打开
	isZhifubaoBrowser: function() {

		var ua = navigator.userAgent.toLowerCase();
		if(ua.match(/Alipay/i) == "Alipay" || ua.match(/alipay/i) == "alipay") {
			return true;
		} else {
			return false;
		}
	},

	/**
	 * 截取地址栏的参数
	 */
//	parseUrlParam: function() {
//		var currentUrl = location.href;
//		var index = currentUrl.indexOf("?");
//		if(index == -1) {
//			return null;
//		}
//
//		var params = currentUrl.substring(index + 1);
//		var paramsSeq = params.split("&");
//		var data = {};
//		for(var i = 0, j = paramsSeq.length; i < j; i++) {
//			var split = paramsSeq[i].split("=");
//			var k = split[0];
//			var v = unescape(split[1]);
//			console.log(k + "=" + v);
//			data[k] = v;
//		}
//
//		return data;
//	},
	/**
	 * 截取地址栏的参数
	 */
	parseUrlParam: function() {
		var currentUrl = location.href;
		var index = currentUrl.indexOf("?");
		if(index == -1) {
			return null;
		}

		var params = currentUrl.substring(index + 1);
		var paramsSeq = params.split("&");
		var data = {};
		for(var i = 0, j = paramsSeq.length; i < j; i++) {
			var split = paramsSeq[i].split("=");
			var k = split[0];
			var v = unescape(split[1]);
			console.log(k + "=" + v);
			data[k] = v;
		}

		return data;
	},
	
	/**
	 * 时间戳转换时间带时分秒
	 */
	formatDate: function(now) {
		var newDate = new Date(now);
		var year = newDate.getFullYear();
		var month = newDate.getMonth() + 1;
		var date = newDate.getDate();
		var hour = newDate.getHours();
		var minute = newDate.getMinutes();
		var second = newDate.getSeconds();
		return year + "-" + FastJs.timeAdd(month) + "-" + FastJs.timeAdd(date) + "   " + FastJs.timeAdd(hour) + ":" + FastJs.timeAdd(minute) + ":" + FastJs.timeAdd(second);
	},
	
	/**
	 * 时间戳转换时间不带时分秒
	 */
	formatDateNoHour: function (nowD) {
		var newDate = new Date(nowD);
		var year = newDate.getFullYear();
		var month = newDate.getMonth() + 1;
		var date = newDate.getDate();
		return year + "-" + FastJs.timeAdd(month) + "-" + FastJs.timeAdd(date) ;
	},
	
	/**
	 * 时间戳转换时间时不足两位数的补0
	 */
	timeAdd: function (m) {
		return m < 10 ? '0' + m : m
	},
	/**
	 * 把数据绑定到表单
	 */
	viewBindData: function(frm, data, dataType) {
		
		var frmData;
		
		if ("json" == dataType || "JSON" == dataType) {
			frmData = data;
			
		} else if ("form" == dataType || "FORM" == dataType) {
			frmData = {};
			var params = data.split("&");
			for (var i = 0, j = params.length; i < j; i++) {
				var seq = params[i];
				var split = seq.split("=");
				if (split.length == 2) {
					var name = split[0];
					var val = split[1];
					frmData[name] = decodeURI(val);
				}
			}
		}
		
		var childrens = frm.children;
		for (var i = 0, j = childrens.length; i < j; i++) {
			
			var e = childrens[i];
			var val = frmData[e.name];
			
			if (null != val && undefined != val) {
				
				var tagName = e.tagName;
				if ("input" == tagName || "INPUT" == tagName
					|| "select" == tagName || "SELECT" == tagName) {
					
					var eType = e.type;
					if ("button" == eType || "BUTTON" == eType) {
						continue;
					}
					if ("checkbox" == eType || "CHECKBOX" == eType
						|| "file" == eType || "FILE" == eType) {
					
					} else {
						
						e.value = val;
					}
				}
			}	
		}
	},

	/**
	 * 获取表单数据
	 */
	getFormData: function(frm, type) {
		
		var childrens = frm.children;
		var data;
		if ("json" == type || "JSON" == type) {
			data = {};
		} else if ("form" == type || "FORM" == type) {
			data = "";
		}
		
		for (var i = 0, j = childrens.length; i < j; i++) {
			var e = childrens[i];
			var tagName = e.tagName;
			if ("input" == tagName || "INPUT" == tagName
				|| "select" == tagName || "SELECT" == tagName) {
				
				var name = e.name;
				var val;
				var eType = e.type;
				if ("button" == eType || "BUTTON" == eType) {
					continue;
				}
				
				if ("checkbox" == eType || "CHECKBOX" == eType
					|| "file" == eType || "FILE" == eType) {
					
				} else {
					
					val = e.value;
				}
				
				// 保存到data
				if (null != name && undefined != name
					&& null != val && undefined != val) {
					if ("json" == type || "JSON" == type) {
						data[name] = val;
					} else if ("form" == type || "FORM" == type) {
						data += "&" + name + "=" + encodeURI(val);
					}
				}
			}
		}
		
		if ("form" == type || "FORM" == type) {
			return "" == data ? data : data.substring(1);
		}
		
		return data;
	},
	
	formatAmount: function(amt) {
		
		amt += "";
		var index = amt.lastIndexOf(".");
		var len = amt.length;
		
		if (index <= 0) {
			return amt + ".00";
		}
		// 小数点后存在位数
		var n = len - 1 - index;
		if (n < 2) {
			for (var i = 0; i < n; i++) {
				amt += "0";
			}
		}
		
		return amt;
	},
	
	/*数组去重*/
	unique : function (arr) {
	    var ret = [];
	    var len = arr.length;
	    for(var i=0; i<len; i++){
	        for(var j=i+1; j<len; j++){
	            if(arr[i] === arr[j]){
	                j = ++i;
	            }
	        }
	        ret.push(arr[i]);
	    }
	    return ret;
	},
	
	/*数组是否为空*/
	isEmptyObject:function(arr){
		var t;  
	    for (t in arr)  
	        return !1;  
	    return !0 
	},
	
	/*删除数组指定key的值*/
	deleteArr:function(jsonArr,name){
		$.each(jsonArr,function(_key){
		    var key = _key;
		    var value = jsonArr[_key];
		    if(_key == name){  //删除
		       delete jsonArr[_key];
		    }
		});
		return jsonArr;
	},
	
	/*删除数组指定的值*/
	deleteArrKey:function(arr, val) {   
	  	for(var i=0; i<arr.length; i++) {
		    if(arr[i] == val) {
		      	arr.splice(i, 1);
		      	break;
		    }
		}   
	}
}

/**
 * 动态加载
 */
//var DynamicLoading = {
//
//	css: function(path) {
//		if(!path || path.length === 0) {
//			throw new Error('argument "path" is required !');
//		}
//		var head = document.getElementsByTagName('head')[0];
//		var link = document.createElement('link');
//		link.href = path;
//		link.rel = 'stylesheet';
//		link.type = 'text/css';
//		head.appendChild(link);
//	},
//
//	js: function(path) {
//		if(!path || path.length === 0) {
//			throw new Error('argument "path" is required !');
//		}
//		var head = document.getElementsByTagName('head')[0];
//		var script = document.createElement('script');
//		script.src = path;
//		script.type = 'text/javascript';
//		head.appendChild(script);
//	},
//
//	/**
//	 * 依赖jquery
//	 * @param {Object} jNode
//	 * @param {Object} pageUrl
//	 * @param {Object} pageNodeId
//	 * @param {Object} data
//	 * @param {Object} callback
//	 */
//	page: function(jNode, pageUrl, pageNodeId, data, callback) {
//
//		if(null == pageNodeId || undefined == pageNodeId) {
//			jNode.load(pageUrl + " #panel", data, callback);
//		} else {
//			jNode.load(pageUrl + " #" + pageNodeId, data, callback);
//		}
//	}
//}