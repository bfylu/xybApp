var GlobalConfig = {
//	merchant : "http://192.168.1.123:8080/merchant",
//	apiPrefix : "http://192.168.1.128:8081/ums",
//	apiCustom : "http://192.168.1.128:8082/xyb",
	merchant : "http://merchant.payadd.cn",
	apiPrefix : "http://ums.payadd.cn",
	apiCustom : "http://xyb.payadd.cn",
	ctx : "merchant",
	
//	xybPrefix : "http://192.168.1.128:8082/xyb",
	xybPrefix : "https://xyb.payadd.cn",
//	xybPrefix : "http://192.168.1.41:58080/xyb",
	
//	tmsPrefix : "http://192.168.1.128:8083/tms",
	tmsPrefix : "https://tms.payadd.cn",
//	tmsPrefix : "http://192.168.1.40:28080/tms/xyb",
//	tmsPrefix : "http://192.168.1.123:54322/tms/xyb",
}

var ImgServerUrl = {
	// 图片服务器地址
	//生产  
	ImgServer : "http://file.payadd.cn/image/view?refNo=" 
	//测试 
//	ImgServer : "http://192.168.1.123:18180/file/image/view?refNo="
//	ImgServer : "http://192.168.1.128:8081/file/image/view?refNo="
}

var _url = "http://merchant.payadd.cn";
//var _url = "http://192.168.1.11:8080/merchant";
var goodsDetailsUrl = "http://192.168.1.5:8020/app-h5/html/goods/goodsDetails.html";
var addGoodsUrl = "http://192.168.1.5:8020/app-h5/html/goods/addGoods.html";
var goodsTypeUrl = "http://192.168.1.5:8020/app-h5/html/goods/categories.html";
var AuthorizeUrl = "http://aeon.payadd.cn/征信授权书.pdf";
//var AuthorizeUrl = "http://web-test.payadd.cn/征信授权书.pdf";

var ApiUrl = {
	/*获取短信验证码*/
	getMsgCode : GlobalConfig.apiPrefix + "/verify/genMsgCode",
	//获取图形验证码
	getImgCode : GlobalConfig.apiPrefix + "/verify/genImgCode",
	// 注册
	registerUser : GlobalConfig.apiPrefix + "/register/user",
	//重发邮箱验证
	reActivate : GlobalConfig.apiPrefix + "/register/reactivate",
	// 重置登录密码
	loginPwd : GlobalConfig.apiPrefix + "/register/reset/loginPwd",
	//邮箱重置密码
	genEmailCode : GlobalConfig.apiPrefix + "/verify/genEmailCode",
	
	//新大陆分期
	getInterface:GlobalConfig.tmsPrefix + "/installment/starPos",
//	getOrderAmt:GlobalConfig.tmsPrefix + "/app?funCode=000016",
//	getInstallFate:GlobalConfig.tmsPrefix + "/app?funCode=000017",
	
	//商品管理
	saveGoodsType : GlobalConfig.apiPrefix + "/merchant/goods/type/save",
	deleteGoods : GlobalConfig.apiPrefix + "/merchant/goods/delete",
	deleteGoodsType : GlobalConfig.apiPrefix + "/merchant/goods/type/delete",
	queryGoodsList : GlobalConfig.apiPrefix + "/merchant/goods/query",
	viewGoods : GlobalConfig.apiPrefix + "/merchant/goods/view",
	queryGoodsTypeList : GlobalConfig.apiPrefix + "/merchant/goods/type/query",
	GoodsTypeSort : GlobalConfig.apiPrefix + "/merchant/goods/type/sort",
	saveGoods : GlobalConfig.apiPrefix + "/merchant/goods/save",
	//商品上下架
	putawayGoods : GlobalConfig.apiPrefix + "/merchant/goods/putaway",
	
	
	//选择商品
	customQueryGoodsList : GlobalConfig.apiCustom + "/customGoods/query",
	customQueryGoodsTypeList : GlobalConfig.apiCustom + "/customGoods/type/query",
	customViewGoods : GlobalConfig.apiCustom + "/customGoods/view",
	viewGoodsSnapshot : GlobalConfig.apiCustom + "/customGoods/viewGoodsSnapshot",
	
	
	
	crerteCodeKey : _url + "/login/crerteCodeKey",
	getVerifyCode : _url +"/verifyCode",
	loginIn : _url +"/login/checkAgentPassword",
	profitTotal : _url +"/agent/profitTotal",
	queryMonthProfit : _url +"/agent/queryMonthProfit",
	queryMonthProfitDetail : _url +"/agent/queryMonthProfitDetail",
	profitRecordDetail : _url +"/agent/profitRecordDetail",
	installmentOrderDetails : _url +"/agent/installmentOrderDetail",
	agentMerchantInfoQuery : _url +"/agent/agentMerchantInfoQuery",
	merchantQuery : _url +"/agent/merchantQuery",
	merchantAcquireQuery : _url +"/agent/merchantAcquireQuery",
	
	chooseMerIncoming : _url +"/uploadData/queryMer",
	checkMerData : _url +"/uploadData/checkMerData",
	queryMerData : _url +"/uploadData/selectMerData",
	merUploadData : _url +"/uploadData/merUploadData",
	uploadDataPic : _url +"/uploadData/uploadDataPic",
	getMerQCode : _url +"/uploadData/getMerQCode",
	downloadMerQCode : _url +"/uploadData/downloadMerQCode",
	getMerQCodeUrl : _url +"/uploadData/getMerQCodeUrl",
	
	//二级代理
	viewAgent : _url +"/agent/view",
	cancelAgent : _url +"/recommend/cancelAgent",
	queryAgentMer : _url +"/recommend/queryAgentMerH5",
	acquireQueryAgentDetail : _url +"/recommend/agentDetails",
	queryOpenedProducts : _url +"/recommend/queryOpenedProducts",
	acquireQueryAmount : _url +"/recommend/queryAmount",
	acquireOpenPro : _url +"/recommend/openPro",
	
	//app申请开通分期 
	openStage : GlobalConfig.xybPrefix +"/installment?funCode=000001",
	openStageSubmit : GlobalConfig.xybPrefix +"/installment?funCode=000002",
	
	//线上商城订单
	onlineOrderList : GlobalConfig.tmsPrefix +"/app?funCode=000008",
	onlineOrderDetails : GlobalConfig.tmsPrefix +"/app?funCode=000009",
	onlineOrderGoods : GlobalConfig.tmsPrefix +"/app?funCode=000013",
	onlineOrderMonth : GlobalConfig.tmsPrefix +"/app?funCode=000012",
	
	//店铺信息
	shopInfoQuery : GlobalConfig.tmsPrefix +"/app?funCode=000015",
	shopInfoSave : GlobalConfig.tmsPrefix +"/app?funCode=000014",
	
}

