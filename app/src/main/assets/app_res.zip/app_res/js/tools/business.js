var businessVal = {"000001":"电商/团购",
	"000002":"线下零售",
	"000003":"生活/家居",
	"000004":"餐饮/食品",
	"000005":"生活/咨询服务",
	"000006":"票务/旅游",
	"000007":"网络虚拟服务",
	"000008":"教育/培训",
	"000009":"娱乐/健身服务",
	"000010":"房地产",
	"000011":"医疗",
	"000012":"收藏/拍卖",
	"000013":"苗木/绿化",
	"000014":"交通运输服务类",
	"000015":"生活缴费",
	"000016":"公益",
	"000017":"通信",
	"000018":"金融",
	"000019":"其他"
};

function business(businessSelect) {
	
	for(var tmp in businessVal) {
		businessSelect.innerHTML += '<option value=' + tmp + '>' + businessVal[tmp] + '</option>';
	}
//	businessSelect.onchange = selectProvince;
}

function getCodeText(code){
	for (var tmp in businessVal) {
		if (code === tmp) {
			return businessVal[tmp];
		}
	}
}

