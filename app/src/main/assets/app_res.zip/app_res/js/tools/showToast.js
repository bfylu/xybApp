var parentDiv, childsDiv, current;
function errorInfo(content,time,status) {
	
	if (null != parentDiv && undefined != parentDiv) {
		childsDiv.textContent = content;
		clearTimeout(current);
		current = setTimeout(function(){
			document.body.removeChild(parentDiv);
			parentDiv = null;
			childsDiv = null;
		}, time);
		return;
	}
	
	var parentCss = "width: 100%;box-sizing: border-box;text-align: center;position: fixed;bottom:50%;z-index: 8888;font-size:18px;";
	var parentCssDefalut = "width: 100%;box-sizing: border-box;text-align: center;position: fixed;bottom:30%;z-index: 8888;font-size:18px;";
	var	childsCssErr = "background-color: #F0F0F0;height:70px;border-radius:5px;line-height:70px;display:inline-block;color: #FF0000;padding:0 50px;border: 1px solid #aaa;";
	var	childsCssSucc = "background-color: #F0F0F0;height:70px;border-radius:5px;line-height:70px;display:inline-block;color: #09bb07;padding:0 50px;border: 1px solid #aaa;";
	var	childsCssDefalut = "font-size:0.7rem;background-color: #000;height:2.2rem;border-radius:2.2rem;line-height:2.2rem;display:inline-block;color: #fff;padding:0 0.8rem;opacity:0.6;";
	
	/*声明创建div*/
	parentDiv = document.createElement("div");
	childsDiv = document.createElement("div");
	
	var conTxt = document.createTextNode(content);
	
	/*传参*/
	childsDiv.appendChild(conTxt);
	
	
	/*写入定义好的样式*/
	parentDiv.style.cssText = parentCss;
	if (status == "error") {
		parentDiv.style.cssText = parentCss;
		childsDiv.style.cssText = childsCssErr;
	} else if(status == "success"){
		parentDiv.style.cssText = parentCss;
		childsDiv.style.cssText = childsCssSucc;
	} else {
		parentDiv.style.cssText = parentCssDefalut;
		childsDiv.style.cssText = childsCssDefalut;
	}
	
	
	/*向body中添加此提示div*/
	document.body.appendChild(parentDiv);
	parentDiv.appendChild(childsDiv);
	
	
	
	/*三秒后移除此div*/
	current = setTimeout(function(){
		document.body.removeChild(parentDiv);
		parentDiv = null;
		childsDiv = null;
	}, time);
	
}


window.showToast = function (content,status) {
	
	errorInfo(content,3000,status);
}

