/** 
 * 初始化iScroll控件 
 */
var dateStatus;
var scrolly;
var myScroll,
	pullDownEl, pullDownOffset,
	pullUpEl, pullUpOffset,
	generatedCount = 0;
	n=0;
function loaded() {
	pullDownEl = document.getElementById('pullDown');
	pullDownOffset = pullDownEl.offsetHeight;
	pullUpEl = document.getElementById('pullUp');
	pullUpOffset = pullUpEl.offsetHeight;

	myScroll = new iScroll('wrapper', {
//		hScrollbar: false, 
//		bounceLock:true,
//		bounce:true,
//		snap:true,
//		momentum:false,
		useTransition: true,
		topOffset: pullDownOffset,
		onRefresh: function() {
			if(pullDownEl.className.match('loading')) {
				pullDownEl.className = '';
				pullDownEl.querySelector('.pullDownLabel').innerHTML = '下拉刷新';
			} else if(pullUpEl.className.match('loading')) {
				pullUpEl.className = '';
				pullUpEl.querySelector('.pullUpLabel').innerHTML = '上拉加载更多';
			}
		},
		onScrollMove: function() {
			if(this.y > 5 && !pullDownEl.className.match('flip')) {
				pullDownEl.className = 'flip';
				pullDownEl.querySelector('.pullDownLabel').innerHTML = '释放刷新';
				this.minScrollY = 0;
			} else if(this.y < 5 && pullDownEl.className.match('flip')) {
				pullDownEl.className = '';
				pullDownEl.querySelector('.pullDownLabel').innerHTML = '下拉刷新';
				this.minScrollY = -pullDownOffset;
			} else if(this.y < (this.maxScrollY - 5) && !pullUpEl.className.match('flip')) {
				pullUpEl.className = 'flip';
				pullUpEl.querySelector('.pullUpLabel').innerHTML = '释放刷新';
				this.maxScrollY = this.maxScrollY;
			} else if(this.y > (this.maxScrollY + 5) && pullUpEl.className.match('flip')) {
				pullUpEl.className = '';
				pullUpEl.querySelector('.pullUpLabel').innerHTML = '上拉加载更多';
				this.maxScrollY = pullUpOffset;
			}else if((this.y < this.maxScrollY) && (this.pointY < 1)){
			    this.scrollTo(0, this.maxScrollY, 400);
			    return;
			} else if (this.y > 0 && (this.pointY > window.innerHeight - 1)) {
			    this.scrollTo(0, 0, 400);
			    return;
			}
		},
		onScrollEnd: function() {
			var height = $(window).height()*2;
			scrolly = Math.abs(this.y)+300;
//			console.log(height);
//			console.log(scrolly);
            if (scrolly>height){  
                $("#go_top").fadeIn(500);  
            }else{  
                $("#go_top").fadeOut(500);  
            }
			if(pullDownEl.className.match('flip')) {
				pullDownEl.className = 'loading';
				pullDownEl.querySelector('.pullDownLabel').innerHTML = '正在加载中';
				pullDownAction(); // Execute custom function (ajax call?)
			} else if(pullUpEl.className.match('flip')) {
				pullUpEl.className = 'loading';
				pullUpEl.querySelector('.pullUpLabel').innerHTML = '正在加载中';
				pullUpAction(); // Execute custom function (ajax call?)
			}
		}
	});

	setTimeout(function() { document.getElementById('wrapper').style.left = '0'; }, 800);
}