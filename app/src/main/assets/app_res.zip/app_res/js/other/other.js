/*上传图片显示缩略图*/
$(".uploadPhoto").on('change',".fileInput",function(){
	var _this = $(this);
	var fr = new FileReader();
	fr.readAsDataURL(this.files[0]);
	console.log(this.files[0].type);
	if(this.files[0].type == "image/png" || this.files[0].type == "image/jpeg" || this.files[0].type == "image/jpg"){
//		if(this.files[0].size >= 50 * 1024 && this.files[0].size <= 1024 * 1024 * 10){
		if(this.files[0].size <= 1024 * 1024 * 10){
			console.log(_this[0].id);
			$("#"+_this[0].id).attr("suppName",_this[0].id);
			console.log($("#"+_this[0].id).attr("suppName"));
			var img = new Image();
			fr.onload = function() {
				img.src = this.result;
				var imgId = _this.parent().siblings().find(".j-img");
				imgId.html(img);
				imgId.css({"width":"10.15rem","height":"6.4rem","overflow":"hidden","display":"block","margin":"0.75rem auto"});
				imgId.find("img").css("height","100%");
				imgId.next("p").css("display","none");
				_this.next().removeClass("regetIos");
				_this.next().removeClass("regetAndroid");
			}
		}else{
			showToast('上传的文件超过了大小限制，请重新上传');
		}
	}else{
		showToast('上传的格式有误，请重新上传');
	}
});